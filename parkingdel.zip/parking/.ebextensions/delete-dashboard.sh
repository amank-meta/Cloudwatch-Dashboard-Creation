#!/bin/bash

python3 /home/delete-dashboard.py
