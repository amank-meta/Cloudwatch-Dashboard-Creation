import boto3
import json

cloudwatch = boto3.client('cloudwatch', region_name='eu-north-1')
ec2 = boto3.client('ec2', region_name='eu-north-1')

dashboard_name = 'MyDashboard'

response = cloudwatch.get_dashboard(DashboardName=dashboard_name)
dashboard_body = json.loads(response['DashboardBody'])

from ec2_metadata import ec2_metadata
instance_id = ec2_metadata.instance_id
print(f"Instance ID: {instance_id}")

# Check the number of instances
#instances = ec2.describe_instances(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
#count = 0
#for reservation in instances['Reservations']:
#for instance in reservation['Instances']:
#count += 1
        
num_widgets = len(dashboard_body["widgets"])
if num_widgets == 2:
    
    response = cloudwatch.delete_dashboards(
        DashboardNames=[dashboard_name]
    )
else:
    print("Inside else")
    for i, widget in enumerate(dashboard_body["widgets"]):
        title = widget.get("properties", {}).get("title")
        print(f"Widget title: {title}")
        expected_title = f"NetworkIn - {instance_id}"
        if title == expected_title:
             print('network deleted')
             del dashboard_body["widgets"][i]
             break
    for i, widget in enumerate(dashboard_body["widgets"]):
        title = widget.get("properties", {}).get("title")
        expected_title = f"CPU Utilization - {instance_id}"
        if title == expected_title:
             del dashboard_body["widgets"][i]
             print('CPU deleted')
             break
    
    response = cloudwatch.put_dashboard(
        DashboardName=dashboard_name,
        DashboardBody=json.dumps(dashboard_body)
    )

