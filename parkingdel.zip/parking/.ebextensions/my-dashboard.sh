#!/bin/bash

python3 /home/my-dashboard.py
