import boto3
import json
cloudwatch = boto3.client('cloudwatch', region_name='eu-north-1')

from ec2_metadata import ec2_metadata
instance_id = ec2_metadata.instance_id
    
try:
  response = cloudwatch.get_dashboard(DashboardName='MyDashboard')
  dashboard_body = json.loads(response['DashboardBody'])
except cloudwatch.exceptions.ResourceNotFound:
  dashboard_body = {"widgets": []}
  
cpu_widget_exists = False
cpu_widget_index = None
for i, widget in enumerate(dashboard_body["widgets"]):
    if widget.get("properties", {}).get("title") == "CPUUtilization - All Instances":
        cpu_widget_exists = True
        cpu_widget_index = i
        
        metrics = widget["properties"]["metrics"]
        
        new_metrics = [
            [
                "AWS/EC2",
                "CPUUtilization",
                "InstanceId",
                instance_id
            ] 
        ]
        metrics.extend(new_metrics)
        widget["properties"]["metrics"] = metrics
        break

cpu_widgets = [] 
cpu_metric = [
    "AWS/EC2",
    "CPUUtilization",
    "InstanceId",
    instance_id
]
cpu_widget = {
    "type": "metric",
    "x": 0,
    "y": len(cpu_widgets),
    "width": 12,
    "height": 6,
    "properties": {
        "metrics": [cpu_metric],
        "view": "timeSeries",
        "stacked": False,
        "region": "eu-north-1",
        "stat": "Average", 
        "period": 60, 
        "title": f"CPU Utilization - {instance_id}"
    }
}
cpu_widgets.append(cpu_widget)
dashboard_body["widgets"] += cpu_widgets

network_widgets = [] 
network_metric = [
    "AWS/EC2",
    "NetworkIn",
    "InstanceId",
    instance_id
]
network_widget = {
    "type": "metric",
    "x": 0,
    "y": len(network_widgets),
    "width": 12,
    "height": 6,
    "properties": {
        "metrics": [network_metric],
        "view": "timeSeries",
        "stacked": False,
        "region": "eu-north-1",
        "stat": "Average", 
        "period": 60, 
        "title": f"NetworkIn - {instance_id}"
    }
}
network_widgets.append(network_widget)
dashboard_body["widgets"] += network_widgets


response = cloudwatch.put_dashboard(
    DashboardName='MyDashboard',
    DashboardBody=json.dumps(dashboard_body)
)




